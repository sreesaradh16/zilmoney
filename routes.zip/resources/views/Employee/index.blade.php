<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<link rel="stylesheet" href="https://cdn.datatables.net/2.2.2/css/dataTables.dataTables.min.css">

<body>
    <a href="{{route('employees.create')}}">Add employee</a>
    <table id="myTable" class="display">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Willing to work</th>
                <th>Languages known</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach($employees as $key=>$employee)
            <tr>
                <td>{{ $key+1 }}</td>
                <td>{{ $employee->name }}</td>
                <td>{{ $employee->willing_to_work == true ? 'Yes' : 'No' }}</td>
                <td>{{ implode(" ",$employee->languageKnown->pluck('language_name')->toArray())  }}</td>
                <td><a href="{{ route('employees.edit',[$employee->id]) }}">Edit</a></td>
                <td><a href="{{ route('employees.destroy',[$employee->id]) }}">Delete</a></td>
            </tr>
            @endforeach
        </tbody>
    </table>
</body>
<script src="https://cdn.datatables.net/2.2.2/js/dataTables.min.js"></script>

</html>
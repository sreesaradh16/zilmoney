<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<link rel="stylesheet" href="https://cdn.datatables.net/2.2.2/css/dataTables.dataTables.min.css">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

<body>
    <form action="{{ route('employees.update',[$employee->id]) }}" method="post">
        @csrf
        @method('put')
        <label for="first_name">First Name</label>
        <input type="text" name="first_name" id="first_name" value="{{ $employee->first_name }}"><br>

        <label for="last_name">Last Name</label>
        <input type="text" name="last_name" id="last_name" value="{{ $employee->last_name }}"><br>

        <label for="willing_to_work">Willing to work</label> 
        <input type="checkbox" name="willing_to_work" id="willing_to_work" value="1" {{ $employee->willing_to_work == 1 ? 'checked' : ''}}><br>

        <label for="languages_known">Languages Known</label>
        <select name="languages_known[]" id="languages_known" class="select2">
            @foreach($languages as $language)
            <option value="{{$language->id}}" {{ in_array($employee->id, $employee->languageKnown()->pluck('employee_id')->toArray())  }}>{{$language->language_name }}</option>
            @endforeach
        </select>
        <button type="submit">Submit</button>
    </form>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

<script src="https://cdn.datatables.net/2.2.2/js/dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2();
    });
</script>

</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<link rel="stylesheet" href="https://cdn.datatables.net/2.2.2/css/dataTables.dataTables.min.css">

<body>
    <a href="<?php echo e(route('employees.create')); ?>">Add employee</a>
    <table id="myTable" class="display">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Willing to work</th>
                <th>Languages known</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key+1); ?></td>
                <td><?php echo e($employee->name); ?></td>
                <td><?php echo e($employee->willing_to_work == true ? 'Yes' : 'No'); ?></td>
                <td><?php echo e(implode(" ",$employee->languageKnown->pluck('language_name')->toArray())); ?></td>
                <td><a href="<?php echo e(route('employees.edit',[$employee->id])); ?>">Edit</a></td>
                <td><a href="<?php echo e(route('employees.destroy',[$employee->id])); ?>">Delete</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
<script src="https://cdn.datatables.net/2.2.2/js/dataTables.min.js"></script>

</html><?php /**PATH C:\Users\ASUS\Desktop\zil-money\resources\views/employee/index.blade.php ENDPATH**/ ?>